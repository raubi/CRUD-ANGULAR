(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin-dashboard/admin-dashboard.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin-dashboard/admin-dashboard.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <!-- Page Wrapper -->\n  <div id=\"wrapper\">\n\n    <!-- Sidebar -->\n    \n    <!-- End of Sidebar -->\n\n    <!-- Content Wrapper -->\n    <div id=\"content-wrapper\" class=\"d-flex flex-column\">\n\n      <!-- Main Content -->\n      <div id=\"content\">\n\n        <!-- End of Topbar -->\n\n        <!-- Begin Page Content -->\n        <div class=\"container-fluid\">\n\n      \n\n          <!-- Content Row -->\n          <div class=\"row\">\n\n            <!-- Earnings (Monthly) Card Example -->\n            <div class=\"col-xl-3 col-md-6 mb-4\">\n              <div class=\"card border-left-primary shadow h-100 py-2\">\n                <div class=\"card-body\">\n                  <div class=\"row no-gutters align-items-center\">\n                    <div class=\"col mr-2\">\n                      <div class=\"text-xs font-weight-bold text-primary text-uppercase mb-1\">Earnings (Monthly)</div>\n                      <div class=\"h5 mb-0 font-weight-bold text-gray-800\">$40,000</div>\n                    </div>\n                    <div class=\"col-auto\">\n                      <i class=\"fas fa-calendar fa-2x text-gray-300\"></i>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n\n            <!-- Earnings (Monthly) Card Example -->\n            <div class=\"col-xl-3 col-md-6 mb-4\">\n              <div class=\"card border-left-success shadow h-100 py-2\">\n                <div class=\"card-body\">\n                  <div class=\"row no-gutters align-items-center\">\n                    <div class=\"col mr-2\">\n                      <div class=\"text-xs font-weight-bold text-success text-uppercase mb-1\">Earnings (Annual)</div>\n                      <div class=\"h5 mb-0 font-weight-bold text-gray-800\">$215,000</div>\n                    </div>\n                    <div class=\"col-auto\">\n                      <i class=\"fas fa-dollar-sign fa-2x text-gray-300\"></i>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n\n            <!-- Earnings (Monthly) Card Example -->\n            <div class=\"col-xl-3 col-md-6 mb-4\">\n              <div class=\"card border-left-info shadow h-100 py-2\">\n                <div class=\"card-body\">\n                  <div class=\"row no-gutters align-items-center\">\n                    <div class=\"col mr-2\">\n                      <div class=\"text-xs font-weight-bold text-info text-uppercase mb-1\">Tasks</div>\n                      <div class=\"row no-gutters align-items-center\">\n                        <div class=\"col-auto\">\n                          <div class=\"h5 mb-0 mr-3 font-weight-bold text-gray-800\">50%</div>\n                        </div>\n                        <div class=\"col\">\n                          <div class=\"progress progress-sm mr-2\">\n                            <div class=\"progress-bar bg-info\" role=\"progressbar\" style=\"width: 50%\" aria-valuenow=\"50\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n                    <div class=\"col-auto\">\n                      <i class=\"fas fa-clipboard-list fa-2x text-gray-300\"></i>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n\n            <!-- Pending Requests Card Example -->\n            <div class=\"col-xl-3 col-md-6 mb-4\">\n              <div class=\"card border-left-warning shadow h-100 py-2\">\n                <div class=\"card-body\">\n                  <div class=\"row no-gutters align-items-center\">\n                    <div class=\"col mr-2\">\n                      <div class=\"text-xs font-weight-bold text-warning text-uppercase mb-1\">Pending Requests</div>\n                      <div class=\"h5 mb-0 font-weight-bold text-gray-800\">18</div>\n                    </div>\n                    <div class=\"col-auto\">\n                      <i class=\"fas fa-comments fa-2x text-gray-300\"></i>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <!-- Content Row -->\n\n        \n\n          <!-- Content Row -->\n          <div class=\"row\">\n\n            <!-- Content Column -->\n            <div class=\"col-lg-6 mb-4\">\n\n              <!-- Project Card Example -->\n              <div class=\"card shadow mb-4\">\n                <div class=\"card-header py-3\">\n                  <h6 class=\"m-0 font-weight-bold text-primary\">Projects</h6>\n                </div>\n                <div class=\"card-body\">\n                  <h4 class=\"small font-weight-bold\">Server Migration <span class=\"float-right\">20%</span></h4>\n                  <div class=\"progress mb-4\">\n                    <div class=\"progress-bar bg-danger\" role=\"progressbar\" style=\"width: 20%\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                  </div>\n                  <h4 class=\"small font-weight-bold\">Sales Tracking <span class=\"float-right\">40%</span></h4>\n                  <div class=\"progress mb-4\">\n                    <div class=\"progress-bar bg-warning\" role=\"progressbar\" style=\"width: 40%\" aria-valuenow=\"40\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                  </div>\n                  <h4 class=\"small font-weight-bold\">Customer Database <span class=\"float-right\">60%</span></h4>\n                  <div class=\"progress mb-4\">\n                    <div class=\"progress-bar\" role=\"progressbar\" style=\"width: 60%\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                  </div>\n                  <h4 class=\"small font-weight-bold\">Payout Details <span class=\"float-right\">80%</span></h4>\n                  <div class=\"progress mb-4\">\n                    <div class=\"progress-bar bg-info\" role=\"progressbar\" style=\"width: 80%\" aria-valuenow=\"80\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                  </div>\n                  <h4 class=\"small font-weight-bold\">Account Setup <span class=\"float-right\">Complete!</span></h4>\n                  <div class=\"progress\">\n                    <div class=\"progress-bar bg-success\" role=\"progressbar\" style=\"width: 100%\" aria-valuenow=\"100\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                  </div>\n                </div>\n              </div>\n\n              <!-- Color System -->\n              <div class=\"row\">\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-primary text-white shadow\">\n                    <div class=\"card-body\">\n                      Primary\n                      <div class=\"text-white-50 small\">#4e73df</div>\n                    </div>\n                  </div>\n                </div>\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-success text-white shadow\">\n                    <div class=\"card-body\">\n                      Success\n                      <div class=\"text-white-50 small\">#1cc88a</div>\n                    </div>\n                  </div>\n                </div>\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-info text-white shadow\">\n                    <div class=\"card-body\">\n                      Info\n                      <div class=\"text-white-50 small\">#36b9cc</div>\n                    </div>\n                  </div>\n                </div>\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-warning text-white shadow\">\n                    <div class=\"card-body\">\n                      Warning\n                      <div class=\"text-white-50 small\">#f6c23e</div>\n                    </div>\n                  </div>\n                </div>\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-danger text-white shadow\">\n                    <div class=\"card-body\">\n                      Danger\n                      <div class=\"text-white-50 small\">#e74a3b</div>\n                    </div>\n                  </div>\n                </div>\n                <div class=\"col-lg-6 mb-4\">\n                  <div class=\"card bg-secondary text-white shadow\">\n                    <div class=\"card-body\">\n                      Secondary\n                      <div class=\"text-white-50 small\">#858796</div>\n                    </div>\n                  </div>\n                </div>\n              </div>\n\n            </div>\n\n            <div class=\"col-lg-6 mb-4\">\n\n              <!-- Illustrations -->\n              <div class=\"card shadow mb-4\">\n                <div class=\"card-header py-3\">\n                  <h6 class=\"m-0 font-weight-bold text-primary\">Illustrations</h6>\n                </div>\n                <div class=\"card-body\">\n                  <div class=\"text-center\">\n                    <img class=\"img-fluid px-3 px-sm-4 mt-3 mb-4\" style=\"width: 25rem;\" src=\"../../../assets/images/phone.png\" alt=\"\">\n                  </div>\n                  <p>Add some quality, svg illustrations to your project courtesy of <a target=\"_blank\" rel=\"nofollow\" href=\"http://www.pickupbasket.com/\">unDraw</a>, a constantly updated collection of beautiful svg images that you can use completely free and without attribution!</p>\n                  <a target=\"_blank\" rel=\"nofollow\" href=\"http://www.pickupbasket.com/\">Browse Illustrations on unDraw &rarr;</a>\n                </div>\n              </div>\n\n              <!-- Approach -->\n              <div class=\"card shadow mb-4\">\n                <div class=\"card-header py-3\">\n                  <h6 class=\"m-0 font-weight-bold text-primary\">Development Approach</h6>\n                </div>\n                <div class=\"card-body\">\n                  <p>SB Admin 2 makes extensive use of Bootstrap 4 utility classes in order to reduce CSS bloat and poor page performance. Custom CSS classes are used to create custom components and custom utility classes.</p>\n                  <p class=\"mb-0\">Before working with this theme, you should become familiar with the Bootstrap framework, especially the utility classes.</p>\n                </div>\n              </div>\n\n            </div>\n          </div>\n\n        </div>\n        <!-- /.container-fluid -->\n\n      </div>\n      <!-- End of Main Content -->\n\n      <!-- Footer -->\n      <footer class=\"sticky-footer bg-white\">\n        <div class=\"container my-auto\">\n          <div class=\"copyright text-center my-auto\">\n            <span>Copyright &copy; Your Website 2019</span>\n          </div>\n        </div>\n      </footer>\n      <!-- End of Footer -->\n\n    </div>\n    <!-- End of Content Wrapper -->\n\n  </div>\n  <!-- End of Page Wrapper -->\n\n  <!-- Scroll to Top Button-->\n  <a class=\"scroll-to-top rounded\" href=\"#page-top\">\n    <i class=\"fas fa-angle-up\"></i>\n  </a>\n\n  <!-- Logout Modal-->\n  <div class=\"modal fade\" id=\"logoutModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">\n    <div class=\"modal-dialog\" role=\"document\">\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <h5 class=\"modal-title\" id=\"exampleModalLabel\">Ready to Leave?</h5>\n          <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">\n            <span aria-hidden=\"true\">×</span>\n          </button>\n        </div>\n        <div class=\"modal-body\">Select \"Logout\" below if you are ready to end your current session.</div>\n        <div class=\"modal-footer\">\n          <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>\n          <a class=\"btn btn-primary\" href=\"login.html\">Logout</a>\n        </div>\n      </div>\n    </div>\n  </div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin/admin.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin/admin.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"dashboard-wrap mtb-40\">\n    <div class=\"container\">\n        <div class=\"row\">\n          <div class=\"col-md-3\">\n              <div class=\"dash-left\">\n                  <ul>\n                      <li><a routerLink=\"./\" routerLinkActive=\"active\" [routerLinkActiveOptions]=\"{ exact: true }\">Dashboard</a></li>\n                      <li><a routerLink=\"./blogs\" routerLinkActive=\"active\">Blogs</a></li>\n                      <li><a routerLink=\"./categories\" routerLinkActive=\"active\">Categories</a></li>\n                      <li><a routerLink=\"./pages\" routerLinkActive=\"active\">Pages</a></li>\n                      <li><a [routerLink]=\"['/login']\">Logout</a></li>\n                  </ul>\n              </div>   \n          </div>\n          <div class=\"col-md-9\">\n              <div class=\"dash-right\">\n                <router-outlet></router-outlet>\n              </div>   \n          </div>\n        </div>\n    </div>\n  </section>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/blog-form/blog-form.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/blog-form/blog-form.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{pageTitle}}</h1>\n    </div>\n  </div>\n  <div class=\"blog-form\">\n    <form [formGroup]=\"blogForm\" (ngSubmit)=\"onSubmit()\">\n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\">Title <span class=\"required\">*</span></label>\n          <div class=\"col-md-9\">\n            <input type=\"text\" formControlName=\"title\" class=\"form-control\" placeholder=\"Title\" required>\n            <div *ngIf=\"title.invalid && (title.dirty || title.touched)\" class=\"error\">\n              <div *ngIf=\"title.errors\">\n                Title is required.\n              </div>\n            </div>\n          </div>\n      </div>\n      <div class=\"form-group form-row\">\n        <label class=\"col-md-3\">Is Featured</label>\n        <div class=\"col-md-9\">\n          <input type=\"radio\" formControlName=\"is_featured\" value=\"1\" /> Yes\n          <input type=\"radio\" formControlName=\"is_featured\" value=\"0\"/> No\n        </div>\n      </div>\n      <div class=\"form-group form-row\">\n        <label class=\"col-md-3\">Is Active</label>\n        <div class=\"col-md-9\">\n          <input type=\"radio\" formControlName=\"is_active\" value=\"1\" /> Yes\n          <input type=\"radio\" formControlName=\"is_active\" value=\"0\" /> No\n        </div>\n      </div>\n      <div class=\"form-group form-row\">\n        <label class=\"col-md-3\">Upload Image</label>\n        <div class=\"col-md-9\">\n          <input type=\"file\" id=\"image\" (change)=\"onSelectedFile($event)\" />\n          <div [innerHTML]=\"uploadError\" class=\"error\"></div>\n          <div *ngIf=\"imagePath\">\n            <br />\n            <img [src]=\"imagePath\" width=\"100px\">\n          </div>\n        </div>\n      </div>\n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\">Description <span class=\"required\">*</span></label>\n          <div class=\"col-md-9\">\n            <textarea formControlName=\"description\" rows=\"5\" class=\"form-control\" placeholder=\"Description\" required></textarea>\n            <div *ngIf=\"description.invalid && (description.dirty || description.touched)\" class=\"error\">\n              <div *ngIf=\"description.errors\">\n                Description is required.\n              </div>\n            </div>\n          </div>\n      </div>\n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\"></label>\n          <div class=\"col-md-9\">\n            <input type=\"hidden\" formControlName=\"id\">\n            <button type=\"submit\" [disabled]=\"!blogForm.valid\" class=\"btn btn-primary\">Save</button>\n          </div>\n      </div>\n    </form>\n  </div>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/category-form/category-form.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/category-form/category-form.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{pageTitle}}</h1>\n    </div>\n  </div>\n  <div class=\"category-form\">\n    <form [formGroup]=\"categoryForm\" (ngSubmit)=\"onSubmit()\">\n    \n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\">Title <span class=\"required\">*</span></label>\n          <div class=\"col-md-9\">\n            <input type=\"text\" formControlName=\"category_name\" class=\"form-control\" placeholder=\"Category Name\" required>\n            <div *ngIf=\"category_name.invalid && (category_name.dirty || category_name.touched)\" class=\"error\">\n              <div *ngIf=\"category_name.errors\">\n                Title is required.\n              </div>\n            </div>\n          </div>\n      </div>\n      \n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\"></label>\n          <div class=\"col-md-9\">\n            <input type=\"hidden\" formControlName=\"id\">\n            <button type=\"submit\" [disabled]=\"!categoryForm.valid\" class=\"btn btn-primary\">Save</button>\n          </div>\n      </div>\n    </form>\n  </div>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/login/login.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/login/login.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>login works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-blogs/manage-blogs.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-blogs/manage-blogs.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{title}}</h1>\n    </div>\n    <div class=\"dash-nav\">\n        <a [routerLink]=\"['/admin/blogs/create']\" class=\"btn btn-success\">Add Post</a>\n    </div>\n  </div>\n  <table class=\"table table-bordered table-striped\">\n    <tr>\n        <th>#ID</th>\n        <th>Image</th>\n        <th>Title</th>\n        <th>Created At</th>\n        <th>Action</th>\n    </tr>\n    <tr *ngFor=\"let blog of blogs\">\n        <td>{{blog.id}}</td>\n        <td><img src=\"{{blog.image}}\" ></td>\n        <td>{{blog.title}}</td>\n        <td>{{blog.created_at | date: 'mediumDate'}}</td>\n        <td class=\"action\">\n            <a [routerLink]=\"['/admin/blogs/edit', blog.id]\" class=\"btn btn-info btn-sm\">Edit</a>\n            <a (click)=\"onDelete(blog.id)\" class=\"btn btn-danger btn-sm\">Delete</a>\n        </td>\n    </tr>\n  </table>\n  {{error}}  \n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-categories/manage-categories.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-categories/manage-categories.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{title}}</h1>\n    </div>\n    <div class=\"dash-nav\">\n        <a [routerLink]=\"['/admin/categories/create']\" class=\"btn btn-success\">Add Category</a>\n    </div>\n  </div>\n  <table class=\"table table-bordered table-striped\">\n    <tr>\n        <th>#ID</th>\n        \n        <th>Title</th>\n      \n        <th>Action</th>\n    </tr>\n    <tr *ngFor=\"let blog of categorys\">\n        <td>{{blog.id}}</td>\n       \n        <td>{{blog.name}}</td>\n       \n        <td class=\"action\">\n            <a [routerLink]=\"['/admin/categories/edit', blog.id]\" class=\"btn btn-info btn-sm\">Edit</a>\n            <a (click)=\"onDelete(blog.id)\" class=\"btn btn-danger btn-sm\">Delete</a>\n        </td>\n    </tr>\n  </table>\n  {{error}}  \n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-pages/manage-pages.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-pages/manage-pages.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{title}}</h1>\n    </div>\n    <div class=\"dash-nav\">\n        <a [routerLink]=\"['/admin/pages/create']\" class=\"btn btn-success\">Add Page</a>\n    </div>\n  </div>\n  <table class=\"table table-bordered table-striped\">\n    <tr>\n        <th>#ID</th>\n      \n        <th>Title</th>\n        <th>Created At</th>\n        <th>Action</th>\n    </tr>\n    <tr *ngFor=\"let blog of pages\">\n        <td>{{blog.id}}</td>\n       \n        <td>{{blog.title}}</td>\n        <td>{{blog.created_at | date: 'mediumDate'}}</td>\n        <td class=\"action\">\n            <a [routerLink]=\"['/admin/pages/edit', blog.id]\" class=\"btn btn-info btn-sm\">Edit</a>\n            <a (click)=\"onDelete(blog.id)\" class=\"btn btn-danger btn-sm\">Delete</a>\n        </td>\n    </tr>\n  </table>\n  {{error}}  \n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/page-form/page-form.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/page-form/page-form.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"dash-header\">\n    <div class=\"dash-title\">\n        <h1>{{pageTitle}}</h1>\n    </div>\n  </div>\n  <div class=\"blog-form\">\n    <form [formGroup]=\"pageForm\" (ngSubmit)=\"onSubmit()\">\n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\">Title <span class=\"required\">*</span></label>\n          <div class=\"col-md-9\">\n            <input type=\"text\" formControlName=\"title\" class=\"form-control\" placeholder=\"Title\" required>\n            <div *ngIf=\"title.invalid && (title.dirty || title.touched)\" class=\"error\">\n              <div *ngIf=\"title.errors\">\n                Title is required.\n              </div>\n            </div>\n          </div>\n      </div>\n     \n      <div class=\"form-group form-row\">\n        <label class=\"col-md-3\">Is Active</label>\n        <div class=\"col-md-9\">\n          <input type=\"radio\" formControlName=\"is_active\" value=\"1\" /> Yes\n          <input type=\"radio\" formControlName=\"is_active\" value=\"0\" /> No\n        </div>\n      </div>\n     \n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\">Description <span class=\"required\">*</span></label>\n          <div class=\"col-md-9\">\n            <textarea formControlName=\"description\" rows=\"5\" class=\"form-control\" placeholder=\"Description\" required></textarea>\n            <div *ngIf=\"description.invalid && (description.dirty || description.touched)\" class=\"error\">\n              <div *ngIf=\"description.errors\">\n                Description is required.\n              </div>\n            </div>\n          </div>\n      </div>\n      <div class=\"form-group form-row\">\n          <label class=\"col-md-3\"></label>\n          <div class=\"col-md-9\">\n            <input type=\"hidden\" formControlName=\"id\">\n            <button type=\"submit\" [disabled]=\"!pageForm.valid\" class=\"btn btn-primary\">Save</button>\n          </div>\n      </div>\n    </form>\n  </div>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\n<app-banner *ngIf=\"router.url == '/'\"></app-banner>\n<app-blogpost-featured *ngIf=\"router.url == '/'\"></app-blogpost-featured>\n<app-footer></app-footer>\n\n<router-outlet></router-outlet>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"login-wrap mtb-40\">\n    <div class=\"container\">\n        <div class=\"row justify-content-center\" *ngIf=\"!error\">\n          <div class=\"col-md-6\">\n              <div class=\"login-box\">\n                  <h1>Administrator Login</h1>\n                  <div class=\"alert alert-danger\" *ngIf=\"loginError\">\n                     {{loginError}}\n                  </div>\n                  <form [formGroup]=\"loginForm\" (ngSubmit)=\"onSubmit()\">\n                      <div class=\"form-group\">\n                          <input type=\"text\" formControlName=\"username\" class=\"form-control\" placeholder=\"Username\" required>\n                          <div *ngIf=\"username.invalid && (username.dirty || username.touched)\" class=\"error\">\n                            <div *ngIf=\"username.errors\">\n                              Username is required.\n                            </div>\n                          </div>\n                      </div>\n                      <div class=\"form-group\">\n                          <input type=\"password\" formControlName=\"password\" class=\"form-control\" placeholder=\"Password\" required>\n                          <div *ngIf=\"password.invalid && (password.dirty || password.touched)\" class=\"error\">\n                            <div *ngIf=\"password.errors\">\n                              Password is required.\n                            </div>\n                          </div>\n                      </div>\n                      <div class=\"form-group\">\n                          <button type=\"submit\" [disabled]=\"!loginForm.valid\" class=\"btn btn-primary\">Log In</button>\n                      </div>\n                  </form>\n              </div>         \n          </div>\n        </div>\n        <div class=\"service-error\" *ngIf=\"error\">\n          <h1>{{error.errorTitle}}</h1>\n          <h3>{{error.errorDesc}}</h3>\n       </div>\n    </div>\n  </section>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/banner/banner.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/banner/banner.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"banner\">\n    <div class=\"banner-box\">\n      <div class=\"intro-text\">\n        <div class=\"intro-text-box\">\n          <h1>Custom Mobile App\n            & Web Development</h1>\n          <p>Looking for a reliable mobile app and web development company for your next project? Hire veteran experts from iPraxa and get your website or mobile app developed within your budget and as per your timeline.</p>\n        </div>\n      </div>\n      <img src=\"assets/images/banner-portfolio.jpg\" alt=\"banner\" />\n    </div>\n  </section>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-detail/blogpost-detail.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-detail/blogpost-detail.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n    <section class=\"blog-detail mtb-40\">\n      <div class=\"container\">\n        <div class=\"row\">\n          <div class=\"col-md-8\">\n            <div class=\"blog-left\" *ngIf=\"blog$ | async as blog else loading\">\n              <h1>{{blog.title}}</h1>\n              <div class=\"posted-on\">\n                  <p>\n                    by <span>{{blog.author}}</span> on \n                    <span>{{blog.created_at | date:'mediumDate'}}</span>\n                  </p>\n              </div>\n              <div class=\"detail-img\">\n                 <img src=\"{{blog.image}}\" alt=\"{{blog.title}}\" />\n              </div>\n              <div class=\"blog-desc\" [innerHTML]=\"blog.description\"></div>\n            </div>\n            <ng-template #loading>\n                <div class=\"service-error\">\n                    <h3>Error loading of the blog detail. Please try again later.</h3>\n                </div>\n            </ng-template>\n          </div>\n          <div class=\"col-md-4\">\n            <app-blogpost-recent></app-blogpost-recent>\n            <app-categories></app-categories>\n          </div>\n        </div>\n      </div>\n    </section>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-featured/blogpost-featured.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-featured/blogpost-featured.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<section class=\"featured-blog mtb-40\">\r\n  \r\n    <div class=\"container\"> \r\n      <i class=\"tag_icon\"></i>\r\n                \r\n                <span class=\"tags_txt\">WHAT WE CREATE</span>\r\n                \r\n                <h2 class=\"recentworkBar\">RECENT PROJECTS <span>The most important project is yours.</span></h2>\r\n      <div class=\"row\">\r\n       \r\n        <div class=\"col-md-4\" *ngFor=\"let blog of blogs\">\r\n          <div class=\"blog-box\">\r\n            <img src=\"{{blog.image}}\" alt=\"blog1\" />\r\n            <h3>{{blog.title}}</h3>\r\n            <p>by <span>{{blog.author}}</span> on <span>{{blog.created_at | date:'mediumDate'}}</span></p>\r\n            <p>{{blog.short_desc}}</p>\r\n           \r\n            <a [routerLink]=\"['/blog', blog.id]\" class=\"btn btn-danger\">Read more...</a>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"service-error\" *ngIf=\"error\">\r\n        <h1>{{error.errorTitle}}</h1>\r\n        <h3>{{error.errorDesc}}</h3>\r\n      </div>\r\n    </div>\r\n  </section>\r\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-list/blogpost-list.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-list/blogpost-list.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"blog-list mtb-40\">\n  <div class=\"container\">\n    <h1>{{title}}</h1>\n    <div class=\"row\">\n      <div class=\"col-md-4\" *ngFor=\"let blog of blogs\">\n        <div class=\"blog-box\">\n          <img src=\"{{blog.image}}\" alt=\"blog1\" />\n          <h3>{{blog.title}}</h3>\n          <p>by <span>{{blog.author}}</span> on <span>{{blog.created_at | date:'mediumDate'}}</span></p>\n          <p>{{blog.short_desc}}</p>\n          <a [routerLink]=\"['/blog', blog.id]\" class=\"btn btn-danger\">Read more...</a>\n          \n        </div>\n      </div>\n    </div>\n    <div class=\"service-error\" *ngIf=\"error\">\n      <h1>{{error.errorTitle}}</h1>\n      <h3>{{error.errorDesc}}</h3>\n    </div>\n  </div>\n</section>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-recent/blogpost-recent.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-recent/blogpost-recent.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"right-widget recent-post\">\n    <h3>Recent Blogs</h3>\n    <div *ngFor=\"let blog of blogs\">\n      <a [routerLink]=\"['/blog', blog.id]\">\n          <div class=\"rb-box\">\n              <div class=\"rb-box-img\">\n                  <img src=\"{{blog.image}}\" alt=\"{{blog.title}}\" />\n              </div>\n              <div class=\"rb-box-desc\">\n                  <h4>{{blog.title}}</h4>\n                  <p>Posted On: {{blog.created_at | date:'mediumDate'}}</p>\n              </div>\n          </div>\n      </a>\n    </div>\n    <div class=\"service-error\" *ngIf=\"error\">\n      <h3>{{error.errorTitle}}</h3>\n      <p>{{error.errorDesc}}<p>\n    </div>\n  </div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/categories/categories.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/categories/categories.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"right-widget categories\">\n    <h3>Categories</h3>\n    <ul>\n       <li *ngFor=\"let categories of category\">{{categories.name}}</li>\n       \n   </ul>\n  </div>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/contact-form/contact-form.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/contact-form/contact-form.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"cmspage mtb-40\">\n  <div class=\"container\">\n    <div class=\"page-desc\" [hidden]=\"submitted\">\n      <div class=\"row justify-content-center\">\n        <div class=\"col-md-8\">\n          <h1>Contact</h1>\n          <form (ngSubmit)=\"onSubmit()\" #contactForm=\"ngForm\">\n            <div class=\"form-group\">\n              <input type=\"text\" name=\"name\" id=\"name\" [(ngModel)]=\"model.name\" class=\"form-control\" placeholder=\"First Name\" required #name=\"ngModel\">\n              <div *ngIf=\"name.invalid && (name.dirty || name.touched)\" class=\"error\">\n                <div *ngIf=\"name.errors.required\">\n                  First name is required.\n                </div>\n              </div>\n            </div>\n            <div class=\"form-group\">\n              <input type=\"text\" name=\"lname\" id=\"lname\" [(ngModel)]=\"model.lname\" class=\"form-control\" placeholder=\"Last Name\" required #lname=\"ngModel\">\n              <div *ngIf=\"lname.invalid && (lname.dirty || lname.touched)\" class=\"error\">\n                <div *ngIf=\"lname.errors.required\">\n                  Last name is required.\n                </div>\n              </div>\n            </div>\n            <div class=\"form-group\">\n              <input type=\"text\" name=\"email\" id=\"email\" [(ngModel)]=\"model.email\" class=\"form-control\" placeholder=\"E-Mail\" required email #email=\"ngModel\">\n              <div *ngIf=\"email.invalid && (email.dirty || email.touched)\" class=\"error\">\n                <div *ngIf=\"email.errors.required\">Email is required.</div>\n                <div *ngIf=\"email.errors.email\">Email must be a valid email address.</div>\n              </div>\n            </div>\n            <div class=\"form-group\">\n              <input type=\"text\" name=\"phone\" id=\"phone\" [(ngModel)]=\"model.phone\" class=\"form-control\" placeholder=\"Phone\">\n            </div>\n            <div class=\"form-group\">\n              <textarea name=\"message\" id=\"message\" [(ngModel)]=\"model.message\" rows=\"5\" class=\"form-control\" placeholder=\"Message\" required #message=\"ngModel\"></textarea>\n              <div *ngIf=\"message.invalid && (message.dirty || message.touched)\" class=\"error\">\n                <div *ngIf=\"message.errors.required\">Message is required.</div>\n              </div>\n            </div>\n            <div class=\"form-group\">\n              <button [disabled]=\"!contactForm.form.valid\" class=\"btn btn-success\">Send Message</button>\n            </div>\n          </form>\n        </div>\n      </div>\n    </div>\n    <div class=\"service-error\" *ngIf=\"error\">\n      <h1>{{error.errorTitle}}</h1>\n      <h3>{{error.errorDesc}}</h3>\n    </div>\n    <div [hidden]=\"!submitted\" class=\"contact-message\">\n      <div *ngIf=\"model.id\" class=\"contact-success\">\n        <h2 class=\"success\">Success!</h2>\n        <h4>Contact form has been successfully submitted.</h4>\n        <br />\n        <button (click)=\"gotoHome()\" class=\"btn btn-info\">Go to Home</button>\n      </div>\n    </div>\n  </div>\n</section>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/page/page.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/page/page.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"cmspage mtb-40\">\n  <div class=\"container\">\n    <div class=\"page-desc\">\n      <h1>{{page.title}}</h1>\n      <div class=\"page-desc\" [innerHTML]=\"page.description\"></div>\n    </div>\n    <div class=\"service-error\" *ngIf=\"error\">\n      <h1>{{error.errorTitle}}</h1>\n      <h3>{{error.errorDesc}}</h3>\n    </div>\n  </div>\n</section>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<footer>\n    <div class=\"container\">\n      <div class=\"copyright\">\n        <div>Designed by IPRAXA</div>\n      </div>\n    </div>\n  </footer>\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<nav class=\"navbar navbar-expand-md navbar-dark bg-blue\">\n    <div class=\"container\">\n      <a class=\"navbar-brand\" routerLink=\"/\" (click)=\"setPageTitle('Blogger')\">\n        <img src=\"assets/images/logo_sticky.png\" alt=\"Angular Project\" />\n      </a>\n      <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarCollapse\" aria-controls=\"navbarCollapse\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n        <span class=\"navbar-toggler-icon\"></span>\n      </button>\n      <div class=\"collapse navbar-collapse\" id=\"navbarCollapse\">\n        <ul class=\"navbar-nav mr-auto\">\n          <li class=\"nav-item active\">\n            <a routerLink=\"/\" routerLinkActive=\"active\" class=\"nav-link\" (click)=\"setPageTitle('Blogger')\">Home</a>\n          </li>\n          <li class=\"nav-item\">\n            <a routerLink=\"/page/about\" routerLinkActive=\"active\" class=\"nav-link\" (click)=\"setPageTitle('About')\">About</a>\n          </li>\n          <li class=\"nav-item\">\n            <a routerLink=\"/page/services\" routerLinkActive=\"active\" class=\"nav-link\" (click)=\"setPageTitle('Services')\">Services</a>\n          </li>\n          <li class=\"nav-item\">\n            <a routerLink=\"/contact\" routerLinkActive=\"active\" class=\"nav-link\" (click)=\"setPageTitle('Contact')\">Contact</a>\n          </li>\n          <li class=\"nav-item\">\n            <a routerLink=\"/blog\" routerLinkActive=\"active\" class=\"nav-link\">Blog</a>\n          </li>\n        </ul>\n        <ul class=\"navbar-nav  ml-auto\">\n          <li class=\"nav-item\" *ngIf=\"!isLoggedIn\">\n            <a routerLink=\"/login\" class=\"nav-link\">Login</a>\n          </li>\n          <li class=\"nav-item\" *ngIf=\"isLoggedIn\">\n            <a routerLink=\"/admin\" class=\"nav-link\">Rupesh Dashboard</a>\n          </li>\n          <li class=\"nav-item\" *ngIf=\"isLoggedIn\">\n              <a routerLink=\"/login\" class=\"nav-link\">Logout</a>\n            </li>\n        </ul>\n      </div>\n    </div>\n  </nav>\n\n  \n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<section class=\"cmspage mtb-40\">\n    <div class=\"container\">\n      <div class=\"error-404\">\n        <h1>404</h1>\n        <h2>There is nothing here!</h2>\n        <p>Sorry, the page you were looking for in this blog does not exist.</p>\n        <button (click)=\"gotoHome()\" class=\"btn btn-danger\">Go to Home</button>\n      </div>\n    </div>\n  </section>\n  ");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),

/***/ "./src/app/admin/admin-dashboard/admin-dashboard.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/admin/admin-dashboard/admin-dashboard.component.css ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL2FkbWluLWRhc2hib2FyZC9hZG1pbi1kYXNoYm9hcmQuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/admin/admin-dashboard/admin-dashboard.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/admin/admin-dashboard/admin-dashboard.component.ts ***!
  \********************************************************************/
/*! exports provided: AdminDashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminDashboardComponent", function() { return AdminDashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AdminDashboardComponent = class AdminDashboardComponent {
    constructor() { }
    ngOnInit() {
    }
};
AdminDashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-admin-dashboard',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./admin-dashboard.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin-dashboard/admin-dashboard.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./admin-dashboard.component.css */ "./src/app/admin/admin-dashboard/admin-dashboard.component.css")).default]
    })
], AdminDashboardComponent);



/***/ }),

/***/ "./src/app/admin/admin-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/admin/admin-routing.module.ts ***!
  \***********************************************/
/*! exports provided: AdminRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminRoutingModule", function() { return AdminRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _admin_admin_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./admin/admin.component */ "./src/app/admin/admin/admin.component.ts");
/* harmony import */ var _admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./admin-dashboard/admin-dashboard.component */ "./src/app/admin/admin-dashboard/admin-dashboard.component.ts");
/* harmony import */ var _manage_blogs_manage_blogs_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./manage-blogs/manage-blogs.component */ "./src/app/admin/manage-blogs/manage-blogs.component.ts");
/* harmony import */ var _manage_categories_manage_categories_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manage-categories/manage-categories.component */ "./src/app/admin/manage-categories/manage-categories.component.ts");
/* harmony import */ var _manage_pages_manage_pages_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./manage-pages/manage-pages.component */ "./src/app/admin/manage-pages/manage-pages.component.ts");
/* harmony import */ var _blog_form_blog_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./blog-form/blog-form.component */ "./src/app/admin/blog-form/blog-form.component.ts");
/* harmony import */ var _category_form_category_form_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./category-form/category-form.component */ "./src/app/admin/category-form/category-form.component.ts");
/* harmony import */ var _page_form_page_form_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./page-form/page-form.component */ "./src/app/admin/page-form/page-form.component.ts");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../auth/auth.guard */ "./src/app/auth/auth.guard.ts");












const routes = [
    {
        path: 'admin',
        component: _admin_admin_component__WEBPACK_IMPORTED_MODULE_3__["AdminComponent"],
        canActivate: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_11__["AuthGuard"]],
        children: [
            {
                path: '',
                children: [
                    { path: 'blogs', component: _manage_blogs_manage_blogs_component__WEBPACK_IMPORTED_MODULE_5__["ManageBlogsComponent"] },
                    { path: 'categories', component: _manage_categories_manage_categories_component__WEBPACK_IMPORTED_MODULE_6__["ManageCategoriesComponent"] },
                    { path: 'pages', component: _manage_pages_manage_pages_component__WEBPACK_IMPORTED_MODULE_7__["ManagePagesComponent"] },
                    { path: 'blogs/create', component: _blog_form_blog_form_component__WEBPACK_IMPORTED_MODULE_8__["BlogFormComponent"] },
                    { path: 'blogs/edit/:id', component: _blog_form_blog_form_component__WEBPACK_IMPORTED_MODULE_8__["BlogFormComponent"] },
                    { path: 'categories/create', component: _category_form_category_form_component__WEBPACK_IMPORTED_MODULE_9__["CategoryFormComponent"] },
                    { path: 'categories/edit/:id', component: _category_form_category_form_component__WEBPACK_IMPORTED_MODULE_9__["CategoryFormComponent"] },
                    { path: 'pages/create', component: _page_form_page_form_component__WEBPACK_IMPORTED_MODULE_10__["PageFormComponent"] },
                    { path: 'pages/edit/:id', component: _page_form_page_form_component__WEBPACK_IMPORTED_MODULE_10__["PageFormComponent"] },
                    { path: '', component: _admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_4__["AdminDashboardComponent"] }
                ],
            }
        ]
    }
];
let AdminRoutingModule = class AdminRoutingModule {
};
AdminRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AdminRoutingModule);



/***/ }),

/***/ "./src/app/admin/admin.module.ts":
/*!***************************************!*\
  !*** ./src/app/admin/admin.module.ts ***!
  \***************************************/
/*! exports provided: AdminModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminModule", function() { return AdminModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _admin_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./admin-routing.module */ "./src/app/admin/admin-routing.module.ts");
/* harmony import */ var _admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./admin-dashboard/admin-dashboard.component */ "./src/app/admin/admin-dashboard/admin-dashboard.component.ts");
/* harmony import */ var _admin_admin_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./admin/admin.component */ "./src/app/admin/admin/admin.component.ts");
/* harmony import */ var _manage_blogs_manage_blogs_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./manage-blogs/manage-blogs.component */ "./src/app/admin/manage-blogs/manage-blogs.component.ts");
/* harmony import */ var _manage_categories_manage_categories_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./manage-categories/manage-categories.component */ "./src/app/admin/manage-categories/manage-categories.component.ts");
/* harmony import */ var _manage_pages_manage_pages_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./manage-pages/manage-pages.component */ "./src/app/admin/manage-pages/manage-pages.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./login/login.component */ "./src/app/admin/login/login.component.ts");
/* harmony import */ var _blog_form_blog_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./blog-form/blog-form.component */ "./src/app/admin/blog-form/blog-form.component.ts");
/* harmony import */ var _category_form_category_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./category-form/category-form.component */ "./src/app/admin/category-form/category-form.component.ts");
/* harmony import */ var _page_form_page_form_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./page-form/page-form.component */ "./src/app/admin/page-form/page-form.component.ts");














let AdminModule = class AdminModule {
};
AdminModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_5__["AdminDashboardComponent"], _admin_admin_component__WEBPACK_IMPORTED_MODULE_6__["AdminComponent"], _manage_blogs_manage_blogs_component__WEBPACK_IMPORTED_MODULE_7__["ManageBlogsComponent"],
            _manage_categories_manage_categories_component__WEBPACK_IMPORTED_MODULE_8__["ManageCategoriesComponent"], _manage_pages_manage_pages_component__WEBPACK_IMPORTED_MODULE_9__["ManagePagesComponent"], _login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"], _blog_form_blog_form_component__WEBPACK_IMPORTED_MODULE_11__["BlogFormComponent"], _category_form_category_form_component__WEBPACK_IMPORTED_MODULE_12__["CategoryFormComponent"], _page_form_page_form_component__WEBPACK_IMPORTED_MODULE_13__["PageFormComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _admin_routing_module__WEBPACK_IMPORTED_MODULE_4__["AdminRoutingModule"]
        ]
    })
], AdminModule);



/***/ }),

/***/ "./src/app/admin/admin/admin.component.css":
/*!*************************************************!*\
  !*** ./src/app/admin/admin/admin.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL2FkbWluL2FkbWluLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/admin/admin/admin.component.ts":
/*!************************************************!*\
  !*** ./src/app/admin/admin/admin.component.ts ***!
  \************************************************/
/*! exports provided: AdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminComponent", function() { return AdminComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AdminComponent = class AdminComponent {
    constructor() { }
    ngOnInit() {
    }
};
AdminComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-admin',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./admin.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/admin/admin.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./admin.component.css */ "./src/app/admin/admin/admin.component.css")).default]
    })
], AdminComponent);



/***/ }),

/***/ "./src/app/admin/blog-form/blog-form.component.css":
/*!*********************************************************!*\
  !*** ./src/app/admin/blog-form/blog-form.component.css ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL2Jsb2ctZm9ybS9ibG9nLWZvcm0uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/admin/blog-form/blog-form.component.ts":
/*!********************************************************!*\
  !*** ./src/app/admin/blog-form/blog-form.component.ts ***!
  \********************************************************/
/*! exports provided: BlogFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogFormComponent", function() { return BlogFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_blog_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/blog.service */ "./src/app/services/blog.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let BlogFormComponent = class BlogFormComponent {
    constructor(fb, blogService, router, route) {
        this.fb = fb;
        this.blogService = blogService;
        this.router = router;
        this.route = route;
    }
    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        if (id) {
            this.pageTitle = 'Edit Blog';
            this.blogService.getBlog(+id).subscribe(res => {
                this.blogForm.patchValue({
                    title: res.title,
                    description: res.description,
                    is_featured: res.is_featured,
                    is_active: res.is_active,
                    id: res.id
                });
                this.imagePath = res.image;
            });
        }
        else {
            this.pageTitle = 'Create Blog';
        }
        this.blogForm = this.fb.group({
            id: [''],
            title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            is_featured: ['0'],
            is_active: ['1'],
            image: [''],
        });
    }
    onSelectedFile(event) {
        if (event.target.files.length > 0) {
            const file = event.target.files[0];
            this.blogForm.get('image').setValue(file);
        }
    }
    get title() { return this.blogForm.get('title'); }
    get description() { return this.blogForm.get('description'); }
    onSubmit() {
        const formData = new FormData();
        formData.append('title', this.blogForm.get('title').value);
        formData.append('description', this.blogForm.get('description').value);
        formData.append('is_featured', this.blogForm.get('is_featured').value);
        formData.append('is_active', this.blogForm.get('is_active').value);
        formData.append('image', this.blogForm.get('image').value);
        const id = this.blogForm.get('id').value;
        if (id) {
            this.blogService.updateBlog(formData, +id).subscribe(res => {
                if (res.status === 'error') {
                    this.uploadError = res.message;
                }
                else {
                    this.router.navigate(['/admin/blogs']);
                }
            }, error => this.error = error);
        }
        else {
            this.blogService.createBlog(formData).subscribe(res => {
                if (res.status === 'error') {
                    this.uploadError = res.message;
                }
                else {
                    this.router.navigate(['/admin/blogs']);
                }
            }, error => this.error = error);
        }
    }
};
BlogFormComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _services_blog_service__WEBPACK_IMPORTED_MODULE_2__["BlogService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
BlogFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blog-form',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./blog-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/blog-form/blog-form.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./blog-form.component.css */ "./src/app/admin/blog-form/blog-form.component.css")).default]
    })
], BlogFormComponent);



/***/ }),

/***/ "./src/app/admin/category-form/category-form.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/admin/category-form/category-form.component.css ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL2NhdGVnb3J5LWZvcm0vY2F0ZWdvcnktZm9ybS5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/admin/category-form/category-form.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/admin/category-form/category-form.component.ts ***!
  \****************************************************************/
/*! exports provided: CategoryFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryFormComponent", function() { return CategoryFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/category.service */ "./src/app/services/category.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let CategoryFormComponent = class CategoryFormComponent {
    constructor(fb, categoryservice, router, route) {
        this.fb = fb;
        this.categoryservice = categoryservice;
        this.router = router;
        this.route = route;
    }
    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        if (id) {
            console.log('Enter');
            this.pageTitle = 'Edit Category';
            this.categoryservice.getCategories(+id).subscribe(res => {
                this.categoryForm.patchValue({
                    id: res.id,
                    title: res.category_name,
                });
                //console.log(res);
            });
        }
        else {
            this.pageTitle = 'Create Category';
        }
        this.categoryForm = this.fb.group({
            id: [''],
            category_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]
        });
    }
    get category_name() {
        return this.categoryForm.get('category_name');
    }
    onSubmit() {
        const formdata = new FormData();
        formdata.append('category_name', this.categoryForm.get('category_name').value);
        const id = this.categoryForm.get('id').value;
        // const id = this.route.snapshot.paramMap.get('id');
        //console.log(id);
        if (id) {
            console.log('update');
            this.categoryservice.updatecategory(formdata, +id).subscribe(res => {
                this.router.navigate(['/admin/categories']);
            });
        }
        else {
            this.categoryservice.createcategory(formdata).subscribe(res => {
                this.router.navigate(['/admin/categories']);
            });
        }
    }
};
CategoryFormComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_2__["CategoryService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
CategoryFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-category-form',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./category-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/category-form/category-form.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./category-form.component.css */ "./src/app/admin/category-form/category-form.component.css")).default]
    })
], CategoryFormComponent);



/***/ }),

/***/ "./src/app/admin/login/login.component.css":
/*!*************************************************!*\
  !*** ./src/app/admin/login/login.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/admin/login/login.component.ts":
/*!************************************************!*\
  !*** ./src/app/admin/login/login.component.ts ***!
  \************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LoginComponent = class LoginComponent {
    constructor() { }
    ngOnInit() {
    }
};
LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/login/login.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.component.css */ "./src/app/admin/login/login.component.css")).default]
    })
], LoginComponent);



/***/ }),

/***/ "./src/app/admin/manage-blogs/manage-blogs.component.css":
/*!***************************************************************!*\
  !*** ./src/app/admin/manage-blogs/manage-blogs.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL21hbmFnZS1ibG9ncy9tYW5hZ2UtYmxvZ3MuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/admin/manage-blogs/manage-blogs.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/admin/manage-blogs/manage-blogs.component.ts ***!
  \**************************************************************/
/*! exports provided: ManageBlogsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageBlogsComponent", function() { return ManageBlogsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_blog_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/blog.service */ "./src/app/services/blog.service.ts");



let ManageBlogsComponent = class ManageBlogsComponent {
    constructor(blogService) {
        this.blogService = blogService;
        this.title = 'Manage Blogs';
    }
    ngOnInit() {
        this.blogService.getBlogs().subscribe((data) => this.blogs = data, error => this.error = error);
    }
    onDelete(id) {
        if (confirm('Are you sure want to delete id = ' + id)) {
            this.blogService.deleteBlog(+id).subscribe(res => {
                console.log(res);
                this.ngOnInit();
            }, error => this.error = error);
        }
    }
};
ManageBlogsComponent.ctorParameters = () => [
    { type: _services_blog_service__WEBPACK_IMPORTED_MODULE_2__["BlogService"] }
];
ManageBlogsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-manage-blogs',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./manage-blogs.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-blogs/manage-blogs.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./manage-blogs.component.css */ "./src/app/admin/manage-blogs/manage-blogs.component.css")).default]
    })
], ManageBlogsComponent);



/***/ }),

/***/ "./src/app/admin/manage-categories/manage-categories.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/admin/manage-categories/manage-categories.component.css ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL21hbmFnZS1jYXRlZ29yaWVzL21hbmFnZS1jYXRlZ29yaWVzLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/admin/manage-categories/manage-categories.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/admin/manage-categories/manage-categories.component.ts ***!
  \************************************************************************/
/*! exports provided: ManageCategoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageCategoriesComponent", function() { return ManageCategoriesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/category.service */ "./src/app/services/category.service.ts");



let ManageCategoriesComponent = class ManageCategoriesComponent {
    constructor(categoryservice) {
        this.categoryservice = categoryservice;
        this.title = 'Manage Category';
    }
    ngOnInit() {
        this.categoryservice.getcategory().subscribe((data) => this.categorys = data, error => this.error = error);
    }
    onDelete(id) {
        if (confirm('Are you sure want to delete category id = ' + id)) {
            this.categoryservice.deleteCategory(+id).subscribe(res => {
                console.log(res);
                this.ngOnInit();
            }, error => this.error = error);
        }
    }
};
ManageCategoriesComponent.ctorParameters = () => [
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_2__["CategoryService"] }
];
ManageCategoriesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-manage-categories',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./manage-categories.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-categories/manage-categories.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./manage-categories.component.css */ "./src/app/admin/manage-categories/manage-categories.component.css")).default]
    })
], ManageCategoriesComponent);



/***/ }),

/***/ "./src/app/admin/manage-pages/manage-pages.component.css":
/*!***************************************************************!*\
  !*** ./src/app/admin/manage-pages/manage-pages.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL21hbmFnZS1wYWdlcy9tYW5hZ2UtcGFnZXMuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/admin/manage-pages/manage-pages.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/admin/manage-pages/manage-pages.component.ts ***!
  \**************************************************************/
/*! exports provided: ManagePagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManagePagesComponent", function() { return ManagePagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_page_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/page.service */ "./src/app/services/page.service.ts");



let ManagePagesComponent = class ManagePagesComponent {
    constructor(pageservice) {
        this.pageservice = pageservice;
        this.title = 'Manage Pages';
    }
    ngOnInit() {
        this.pageservice.getPages().subscribe((data) => this.pages = data, error => this.error = error);
    }
    onDelete(id) {
        if (confirm('Are you sure want to delete page id = ' + id)) {
            this.pageservice.deletepage(+id).subscribe(res => {
                console.log(res);
                this.ngOnInit();
            }, error => this.error = error);
        }
    }
};
ManagePagesComponent.ctorParameters = () => [
    { type: _services_page_service__WEBPACK_IMPORTED_MODULE_2__["PageService"] }
];
ManagePagesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-manage-pages',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./manage-pages.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/manage-pages/manage-pages.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./manage-pages.component.css */ "./src/app/admin/manage-pages/manage-pages.component.css")).default]
    })
], ManagePagesComponent);



/***/ }),

/***/ "./src/app/admin/page-form/page-form.component.css":
/*!*********************************************************!*\
  !*** ./src/app/admin/page-form/page-form.component.css ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3BhZ2UtZm9ybS9wYWdlLWZvcm0uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/admin/page-form/page-form.component.ts":
/*!********************************************************!*\
  !*** ./src/app/admin/page-form/page-form.component.ts ***!
  \********************************************************/
/*! exports provided: PageFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageFormComponent", function() { return PageFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_page_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/page.service */ "./src/app/services/page.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let PageFormComponent = class PageFormComponent {
    constructor(fb, pageService, router, route) {
        this.fb = fb;
        this.pageService = pageService;
        this.router = router;
        this.route = route;
    }
    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        if (id) {
            this.pageTitle = 'Edit Page';
            this.pageService.getPage(+id).subscribe(res => {
                this.pageForm.patchValue({
                    title: res.title,
                    description: res.description,
                    is_active: res.is_active,
                    id: res.id
                });
            });
        }
        else {
            this.pageTitle = 'Create Page';
        }
        this.pageForm = this.fb.group({
            id: [''],
            title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            is_active: ['1'],
        });
    }
    get title() { return this.pageForm.get('title'); }
    get description() { return this.pageForm.get('description'); }
    onSubmit() {
        const formData = new FormData();
        formData.append('title', this.pageForm.get('title').value);
        formData.append('description', this.pageForm.get('description').value);
        formData.append('is_active', this.pageForm.get('is_active').value);
        const id = this.pageForm.get('id').value;
        if (id) {
            this.pageService.updatepage(formData, +id).subscribe(res => {
                this.router.navigate(['/admin/pages']);
            });
        }
        else {
            this.pageService.createpage(formData).subscribe(res => {
                this.router.navigate(['/admin/pages']);
            });
        }
    }
};
PageFormComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _services_page_service__WEBPACK_IMPORTED_MODULE_2__["PageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
PageFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-page-form',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./page-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/page-form/page-form.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./page-form.component.css */ "./src/app/admin/page-form/page-form.component.css")).default]
    })
], PageFormComponent);



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");




const routes = [
    { path: '', redirectTo: '', pathMatch: 'full' },
    { path: '**', component: _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_3__["PageNotFoundComponent"] }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let AppComponent = class AppComponent {
    constructor(router) {
        this.router = router;
        this.title = 'ipraxa';
    }
};
AppComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _blogpost_blogpost_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./blogpost/blogpost.module */ "./src/app/blogpost/blogpost.module.ts");
/* harmony import */ var _cmspage_cmspage_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cmspage/cmspage.module */ "./src/app/cmspage/cmspage.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _banner_banner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./banner/banner.component */ "./src/app/banner/banner.component.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var _admin_admin_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./admin/admin.module */ "./src/app/admin/admin.module.ts");
/* harmony import */ var _auth_auth_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./auth/auth.module */ "./src/app/auth/auth.module.ts");
/* harmony import */ var _http_interceptors_index__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./http-interceptors/index */ "./src/app/http-interceptors/index.ts");















let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
            _header_header_component__WEBPACK_IMPORTED_MODULE_8__["HeaderComponent"],
            _footer_footer_component__WEBPACK_IMPORTED_MODULE_9__["FooterComponent"],
            _banner_banner_component__WEBPACK_IMPORTED_MODULE_10__["BannerComponent"],
            _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_11__["PageNotFoundComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
            _blogpost_blogpost_module__WEBPACK_IMPORTED_MODULE_5__["BlogpostModule"],
            _cmspage_cmspage_module__WEBPACK_IMPORTED_MODULE_6__["CmspageModule"],
            _admin_admin_module__WEBPACK_IMPORTED_MODULE_12__["AdminModule"],
            _auth_auth_module__WEBPACK_IMPORTED_MODULE_13__["AuthModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"]
        ],
        providers: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Title"],
            _http_interceptors_index__WEBPACK_IMPORTED_MODULE_14__["httpInterceptorProviders"]
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/auth/auth-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/*! exports provided: AuthRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthRoutingModule", function() { return AuthRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login/login.component */ "./src/app/auth/login/login.component.ts");




const routes = [
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] }
];
let AuthRoutingModule = class AuthRoutingModule {
};
AuthRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AuthRoutingModule);



/***/ }),

/***/ "./src/app/auth/auth.guard.ts":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");




let AuthGuard = class AuthGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(route, state) {
        const url = state.url;
        return this.checkLogin(url);
    }
    canActivateChild(route, state) {
        return this.canActivate(route, state);
    }
    checkLogin(url) {
        if (this.authService.isLoggedIn()) {
            return true;
        }
        this.authService.redirectUrl = url;
        this.router.navigate(['/login'], { queryParams: { returnUrl: url } });
    }
};
AuthGuard.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ "./src/app/auth/auth.module.ts":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: AuthModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthModule", function() { return AuthModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth-routing.module */ "./src/app/auth/auth-routing.module.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login/login.component */ "./src/app/auth/login/login.component.ts");






let AuthModule = class AuthModule {
};
AuthModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _auth_routing_module__WEBPACK_IMPORTED_MODULE_4__["AuthRoutingModule"]
        ],
        declarations: [_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"]],
    })
], AuthModule);



/***/ }),

/***/ "./src/app/auth/auth.service.ts":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
    }
    login(username, password) {
        return this.http.post(`${this.serverUrl}api/login`, { username: username, password: password })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(user => {
            if (user && user.token) {
                localStorage.setItem('currentUser', JSON.stringify(user));
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    isLoggedIn() {
        if (localStorage.getItem('currentUser')) {
            return true;
        }
        return false;
    }
    getAuthorizationToken() {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        return currentUser.token;
    }
    logout() {
        localStorage.removeItem('currentUser');
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        this.errorData = {
            errorTitle: 'Oops! Request for document failed',
            errorDesc: 'Something bad happened. Please try again later.'
        };
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(this.errorData);
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ "./src/app/auth/login/login.component.css":
/*!************************************************!*\
  !*** ./src/app/auth/login/login.component.css ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/auth/login/login.component.ts":
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");





let LoginComponent = class LoginComponent {
    constructor(fb, router, authService) {
        this.fb = fb;
        this.router = router;
        this.authService = authService;
        this.submitted = false;
    }
    ngOnInit() {
        this.loginForm = this.fb.group({
            username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        this.authService.logout();
    }
    get username() { return this.loginForm.get('username'); }
    get password() { return this.loginForm.get('password'); }
    onSubmit() {
        this.submitted = true;
        this.authService.login(this.username.value, this.password.value).subscribe((data) => {
            if (this.authService.isLoggedIn) {
                const redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/admin';
                this.router.navigate([redirect]);
            }
            else {
                // console.log("Hello");
                this.loginError = 'Username or password is incorrect.';
            }
        }, error => this.error = error);
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
];
LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.component.css */ "./src/app/auth/login/login.component.css")).default]
    })
], LoginComponent);



/***/ }),

/***/ "./src/app/banner/banner.component.css":
/*!*********************************************!*\
  !*** ./src/app/banner/banner.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jhbm5lci9iYW5uZXIuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/banner/banner.component.ts":
/*!********************************************!*\
  !*** ./src/app/banner/banner.component.ts ***!
  \********************************************/
/*! exports provided: BannerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BannerComponent", function() { return BannerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let BannerComponent = class BannerComponent {
    constructor() { }
    ngOnInit() {
    }
};
BannerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-banner',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./banner.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/banner/banner.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./banner.component.css */ "./src/app/banner/banner.component.css")).default]
    })
], BannerComponent);



/***/ }),

/***/ "./src/app/blogpost/blogpost-detail/blogpost-detail.component.css":
/*!************************************************************************!*\
  !*** ./src/app/blogpost/blogpost-detail/blogpost-detail.component.css ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jsb2dwb3N0L2Jsb2dwb3N0LWRldGFpbC9ibG9ncG9zdC1kZXRhaWwuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/blogpost/blogpost-detail/blogpost-detail.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/blogpost/blogpost-detail/blogpost-detail.component.ts ***!
  \***********************************************************************/
/*! exports provided: BlogpostDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostDetailComponent", function() { return BlogpostDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _blogpost_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../blogpost.service */ "./src/app/blogpost/blogpost.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");






let BlogpostDetailComponent = class BlogpostDetailComponent {
    constructor(route, router, blogpostService, titleService) {
        this.route = route;
        this.router = router;
        this.blogpostService = blogpostService;
        this.titleService = titleService;
    }
    ngOnInit() {
        this.blog$ = this.route.paramMap.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])((params) => this.blogpostService.getBlog(+params.get('id'))));
        this.titleService.setTitle('Blog Detail');
    }
};
BlogpostDetailComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _blogpost_service__WEBPACK_IMPORTED_MODULE_3__["BlogpostService"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["Title"] }
];
BlogpostDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blogpost-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./blogpost-detail.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-detail/blogpost-detail.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./blogpost-detail.component.css */ "./src/app/blogpost/blogpost-detail/blogpost-detail.component.css")).default]
    })
], BlogpostDetailComponent);



/***/ }),

/***/ "./src/app/blogpost/blogpost-featured/blogpost-featured.component.css":
/*!****************************************************************************!*\
  !*** ./src/app/blogpost/blogpost-featured/blogpost-featured.component.css ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jsb2dwb3N0L2Jsb2dwb3N0LWZlYXR1cmVkL2Jsb2dwb3N0LWZlYXR1cmVkLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/blogpost/blogpost-featured/blogpost-featured.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/blogpost/blogpost-featured/blogpost-featured.component.ts ***!
  \***************************************************************************/
/*! exports provided: BlogpostFeaturedComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostFeaturedComponent", function() { return BlogpostFeaturedComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _blogpost_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../blogpost.service */ "./src/app/blogpost/blogpost.service.ts");



let BlogpostFeaturedComponent = class BlogpostFeaturedComponent {
    constructor(blogpostService) {
        this.blogpostService = blogpostService;
    }
    ngOnInit() {
        this.blogpostService.getFeaturedBlogs().subscribe((data) => this.blogs = data, error => this.error = error);
    }
};
BlogpostFeaturedComponent.ctorParameters = () => [
    { type: _blogpost_service__WEBPACK_IMPORTED_MODULE_2__["BlogpostService"] }
];
BlogpostFeaturedComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blogpost-featured',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./blogpost-featured.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-featured/blogpost-featured.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./blogpost-featured.component.css */ "./src/app/blogpost/blogpost-featured/blogpost-featured.component.css")).default]
    })
], BlogpostFeaturedComponent);



/***/ }),

/***/ "./src/app/blogpost/blogpost-list/blogpost-list.component.css":
/*!********************************************************************!*\
  !*** ./src/app/blogpost/blogpost-list/blogpost-list.component.css ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jsb2dwb3N0L2Jsb2dwb3N0LWxpc3QvYmxvZ3Bvc3QtbGlzdC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/blogpost/blogpost-list/blogpost-list.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/blogpost/blogpost-list/blogpost-list.component.ts ***!
  \*******************************************************************/
/*! exports provided: BlogpostListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostListComponent", function() { return BlogpostListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _blogpost_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../blogpost.service */ "./src/app/blogpost/blogpost.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");




let BlogpostListComponent = class BlogpostListComponent {
    constructor(titleService, blogpostService) {
        this.titleService = titleService;
        this.blogpostService = blogpostService;
        this.title = 'Blogs';
    }
    ngOnInit() {
        this.titleService.setTitle(this.title);
        this.blogpostService.getBlogs().subscribe((data) => this.blogs = data, error => this.error = error);
    }
};
BlogpostListComponent.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["Title"] },
    { type: _blogpost_service__WEBPACK_IMPORTED_MODULE_2__["BlogpostService"] }
];
BlogpostListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blogpost-list',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./blogpost-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-list/blogpost-list.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./blogpost-list.component.css */ "./src/app/blogpost/blogpost-list/blogpost-list.component.css")).default]
    })
], BlogpostListComponent);



/***/ }),

/***/ "./src/app/blogpost/blogpost-recent/blogpost-recent.component.css":
/*!************************************************************************!*\
  !*** ./src/app/blogpost/blogpost-recent/blogpost-recent.component.css ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jsb2dwb3N0L2Jsb2dwb3N0LXJlY2VudC9ibG9ncG9zdC1yZWNlbnQuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/blogpost/blogpost-recent/blogpost-recent.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/blogpost/blogpost-recent/blogpost-recent.component.ts ***!
  \***********************************************************************/
/*! exports provided: BlogpostRecentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostRecentComponent", function() { return BlogpostRecentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _blogpost_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../blogpost.service */ "./src/app/blogpost/blogpost.service.ts");



let BlogpostRecentComponent = class BlogpostRecentComponent {
    constructor(blogpostService) {
        this.blogpostService = blogpostService;
    }
    ngOnInit() {
        this.blogpostService.getRecentBlogs().subscribe((data) => this.blogs = data, error => this.error = error);
    }
};
BlogpostRecentComponent.ctorParameters = () => [
    { type: _blogpost_service__WEBPACK_IMPORTED_MODULE_2__["BlogpostService"] }
];
BlogpostRecentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blogpost-recent',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./blogpost-recent.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/blogpost-recent/blogpost-recent.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./blogpost-recent.component.css */ "./src/app/blogpost/blogpost-recent/blogpost-recent.component.css")).default]
    })
], BlogpostRecentComponent);



/***/ }),

/***/ "./src/app/blogpost/blogpost-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/blogpost/blogpost-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: BlogpostRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostRoutingModule", function() { return BlogpostRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _blogpost_list_blogpost_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./blogpost-list/blogpost-list.component */ "./src/app/blogpost/blogpost-list/blogpost-list.component.ts");
/* harmony import */ var _blogpost_detail_blogpost_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./blogpost-detail/blogpost-detail.component */ "./src/app/blogpost/blogpost-detail/blogpost-detail.component.ts");





const routes = [
    { path: 'blog', component: _blogpost_list_blogpost_list_component__WEBPACK_IMPORTED_MODULE_3__["BlogpostListComponent"] },
    { path: 'blog/:id', component: _blogpost_detail_blogpost_detail_component__WEBPACK_IMPORTED_MODULE_4__["BlogpostDetailComponent"] }
];
let BlogpostRoutingModule = class BlogpostRoutingModule {
};
BlogpostRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], BlogpostRoutingModule);



/***/ }),

/***/ "./src/app/blogpost/blogpost.module.ts":
/*!*********************************************!*\
  !*** ./src/app/blogpost/blogpost.module.ts ***!
  \*********************************************/
/*! exports provided: BlogpostModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostModule", function() { return BlogpostModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _blogpost_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./blogpost-routing.module */ "./src/app/blogpost/blogpost-routing.module.ts");
/* harmony import */ var _blogpost_featured_blogpost_featured_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./blogpost-featured/blogpost-featured.component */ "./src/app/blogpost/blogpost-featured/blogpost-featured.component.ts");
/* harmony import */ var _blogpost_list_blogpost_list_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./blogpost-list/blogpost-list.component */ "./src/app/blogpost/blogpost-list/blogpost-list.component.ts");
/* harmony import */ var _blogpost_detail_blogpost_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./blogpost-detail/blogpost-detail.component */ "./src/app/blogpost/blogpost-detail/blogpost-detail.component.ts");
/* harmony import */ var _blogpost_recent_blogpost_recent_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./blogpost-recent/blogpost-recent.component */ "./src/app/blogpost/blogpost-recent/blogpost-recent.component.ts");
/* harmony import */ var _categories_categories_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./categories/categories.component */ "./src/app/blogpost/categories/categories.component.ts");









let BlogpostModule = class BlogpostModule {
};
BlogpostModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_blogpost_featured_blogpost_featured_component__WEBPACK_IMPORTED_MODULE_4__["BlogpostFeaturedComponent"], _blogpost_list_blogpost_list_component__WEBPACK_IMPORTED_MODULE_5__["BlogpostListComponent"], _blogpost_detail_blogpost_detail_component__WEBPACK_IMPORTED_MODULE_6__["BlogpostDetailComponent"], _blogpost_recent_blogpost_recent_component__WEBPACK_IMPORTED_MODULE_7__["BlogpostRecentComponent"], _categories_categories_component__WEBPACK_IMPORTED_MODULE_8__["CategoriesComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _blogpost_routing_module__WEBPACK_IMPORTED_MODULE_3__["BlogpostRoutingModule"]
        ],
        exports: [
            _blogpost_featured_blogpost_featured_component__WEBPACK_IMPORTED_MODULE_4__["BlogpostFeaturedComponent"]
        ]
    })
], BlogpostModule);



/***/ }),

/***/ "./src/app/blogpost/blogpost.service.ts":
/*!**********************************************!*\
  !*** ./src/app/blogpost/blogpost.service.ts ***!
  \**********************************************/
/*! exports provided: BlogpostService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogpostService", function() { return BlogpostService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let BlogpostService = class BlogpostService {
    constructor(handler) {
        this.ServerUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
        this.http = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"](handler);
    }
    getBlogs() {
        //console.log('hello');
        return this.http.get(this.ServerUrl + 'api/blogs').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getFeaturedBlogs() {
        return this.http.get(this.ServerUrl + 'api/featured_blogs').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getCategary() {
        return this.http.get(this.ServerUrl + 'api/categories').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getRecentBlogs() {
        return this.http.get(this.ServerUrl + 'api/recent_blogs').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getBlog(id) {
        return this.http.get(this.ServerUrl + 'api/blog/' + id)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        this.errorData = {
            errorTitle: 'Oops! Request for document failed',
            errorDesc: 'Something bad happened. Please try again later.'
        };
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(this.errorData);
    }
};
BlogpostService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpBackend"] }
];
BlogpostService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], BlogpostService);



/***/ }),

/***/ "./src/app/blogpost/categories/categories.component.css":
/*!**************************************************************!*\
  !*** ./src/app/blogpost/categories/categories.component.css ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jsb2dwb3N0L2NhdGVnb3JpZXMvY2F0ZWdvcmllcy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/blogpost/categories/categories.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/blogpost/categories/categories.component.ts ***!
  \*************************************************************/
/*! exports provided: CategoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoriesComponent", function() { return CategoriesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _blogpost_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../blogpost.service */ "./src/app/blogpost/blogpost.service.ts");



let CategoriesComponent = class CategoriesComponent {
    constructor(blogpostService) {
        this.blogpostService = blogpostService;
    }
    ngOnInit() {
        this.blogpostService.getCategary().subscribe((data) => this.category = data, error => this.error = error);
    }
};
CategoriesComponent.ctorParameters = () => [
    { type: _blogpost_service__WEBPACK_IMPORTED_MODULE_2__["BlogpostService"] }
];
CategoriesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-categories',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./categories.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/blogpost/categories/categories.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./categories.component.css */ "./src/app/blogpost/categories/categories.component.css")).default]
    })
], CategoriesComponent);



/***/ }),

/***/ "./src/app/cmspage/cmspage-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/cmspage/cmspage-routing.module.ts ***!
  \***************************************************/
/*! exports provided: CmspageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CmspageRoutingModule", function() { return CmspageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _page_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page/page.component */ "./src/app/cmspage/page/page.component.ts");
/* harmony import */ var _contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./contact-form/contact-form.component */ "./src/app/cmspage/contact-form/contact-form.component.ts");





const routes = [
    { path: 'page/:slug', component: _page_page_component__WEBPACK_IMPORTED_MODULE_3__["PageComponent"] },
    { path: 'contact', component: _contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_4__["ContactFormComponent"] }
];
let CmspageRoutingModule = class CmspageRoutingModule {
};
CmspageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], CmspageRoutingModule);



/***/ }),

/***/ "./src/app/cmspage/cmspage.module.ts":
/*!*******************************************!*\
  !*** ./src/app/cmspage/cmspage.module.ts ***!
  \*******************************************/
/*! exports provided: CmspageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CmspageModule", function() { return CmspageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _cmspage_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cmspage-routing.module */ "./src/app/cmspage/cmspage-routing.module.ts");
/* harmony import */ var _page_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page/page.component */ "./src/app/cmspage/page/page.component.ts");
/* harmony import */ var _contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./contact-form/contact-form.component */ "./src/app/cmspage/contact-form/contact-form.component.ts");







let CmspageModule = class CmspageModule {
};
CmspageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _cmspage_routing_module__WEBPACK_IMPORTED_MODULE_4__["CmspageRoutingModule"]
        ],
        declarations: [_page_page_component__WEBPACK_IMPORTED_MODULE_5__["PageComponent"], _contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_6__["ContactFormComponent"]]
    })
], CmspageModule);



/***/ }),

/***/ "./src/app/cmspage/cmspage.service.ts":
/*!********************************************!*\
  !*** ./src/app/cmspage/cmspage.service.ts ***!
  \********************************************/
/*! exports provided: CmspageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CmspageService", function() { return CmspageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let CmspageService = class CmspageService {
    constructor(handler) {
        this.ServerUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        this.http = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"](handler);
    }
    getPage(slug) {
        return this.http.get(this.ServerUrl + 'api/page/' + slug)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    contactForm(formdata) {
        return this.http.post(this.ServerUrl + 'api/contact', formdata, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        this.errorData = {
            errorTitle: 'Oops! Request for document failed',
            errorDesc: 'Something bad happened. Please try again later.'
        };
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(this.errorData);
    }
};
CmspageService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpBackend"] }
];
CmspageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CmspageService);



/***/ }),

/***/ "./src/app/cmspage/contact-form/contact-form.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/cmspage/contact-form/contact-form.component.css ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Ntc3BhZ2UvY29udGFjdC1mb3JtL2NvbnRhY3QtZm9ybS5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/cmspage/contact-form/contact-form.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/cmspage/contact-form/contact-form.component.ts ***!
  \****************************************************************/
/*! exports provided: ContactFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactFormComponent", function() { return ContactFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _contact__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contact */ "./src/app/cmspage/contact.ts");
/* harmony import */ var _cmspage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../cmspage.service */ "./src/app/cmspage/cmspage.service.ts");





let ContactFormComponent = class ContactFormComponent {
    constructor(router, cmspageService) {
        this.router = router;
        this.cmspageService = cmspageService;
        this.model = new _contact__WEBPACK_IMPORTED_MODULE_3__["Contact"]();
        this.submitted = false;
    }
    ngOnInit() {
    }
    onSubmit() {
        this.submitted = true;
        return this.cmspageService.contactForm(this.model).subscribe(data => this.model = data, error => this.error = error);
    }
    gotoHome() {
        this.router.navigate(['/']);
    }
};
ContactFormComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _cmspage_service__WEBPACK_IMPORTED_MODULE_4__["CmspageService"] }
];
ContactFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-contact-form',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./contact-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/contact-form/contact-form.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./contact-form.component.css */ "./src/app/cmspage/contact-form/contact-form.component.css")).default]
    })
], ContactFormComponent);



/***/ }),

/***/ "./src/app/cmspage/contact.ts":
/*!************************************!*\
  !*** ./src/app/cmspage/contact.ts ***!
  \************************************/
/*! exports provided: Contact */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Contact", function() { return Contact; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

class Contact {
}


/***/ }),

/***/ "./src/app/cmspage/page/page.component.css":
/*!*************************************************!*\
  !*** ./src/app/cmspage/page/page.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Ntc3BhZ2UvcGFnZS9wYWdlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/cmspage/page/page.component.ts":
/*!************************************************!*\
  !*** ./src/app/cmspage/page/page.component.ts ***!
  \************************************************/
/*! exports provided: PageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageComponent", function() { return PageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _cmspage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../cmspage.service */ "./src/app/cmspage/cmspage.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");





let PageComponent = class PageComponent {
    constructor(route, cmspageService) {
        this.route = route;
        this.cmspageService = cmspageService;
    }
    ngOnInit() {
        this.route.paramMap.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((params) => this.cmspageService.getPage(params.get('slug')))).subscribe((data) => this.page = data, error => this.error = error);
        //console.log(data);
    }
};
PageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _cmspage_service__WEBPACK_IMPORTED_MODULE_3__["CmspageService"] }
];
PageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-page',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./page.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cmspage/page/page.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./page.component.css */ "./src/app/cmspage/page/page.component.css")).default]
    })
], PageComponent);



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
};
FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-footer',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")).default]
    })
], FooterComponent);



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");




let HeaderComponent = class HeaderComponent {
    constructor(titleService, authService) {
        this.titleService = titleService;
        this.authService = authService;
    }
    ngOnInit() {
    }
    get isLoggedIn() { return this.authService.isLoggedIn(); }
    setPageTitle(title) {
        this.titleService.setTitle(title);
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["Title"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
];
HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")).default]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/http-interceptors/auth-interceptor.ts":
/*!*******************************************************!*\
  !*** ./src/app/http-interceptors/auth-interceptor.ts ***!
  \*******************************************************/
/*! exports provided: AuthInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthInterceptor", function() { return AuthInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");



let AuthInterceptor = class AuthInterceptor {
    constructor(authService) {
        this.authService = authService;
    }
    intercept(req, next) {
        if (this.authService.isLoggedIn()) {
            const authToken = this.authService.getAuthorizationToken();
            req = req.clone({
                setHeaders: { Authorization: authToken }
            });
        }
        return next.handle(req);
    }
};
AuthInterceptor.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
];
AuthInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], AuthInterceptor);



/***/ }),

/***/ "./src/app/http-interceptors/index.ts":
/*!********************************************!*\
  !*** ./src/app/http-interceptors/index.ts ***!
  \********************************************/
/*! exports provided: httpInterceptorProviders */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "httpInterceptorProviders", function() { return httpInterceptorProviders; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _auth_interceptor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth-interceptor */ "./src/app/http-interceptors/auth-interceptor.ts");



const httpInterceptorProviders = [
    { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HTTP_INTERCEPTORS"], useClass: _auth_interceptor__WEBPACK_IMPORTED_MODULE_2__["AuthInterceptor"], multi: true }
];


/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.css":
/*!*************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2Utbm90LWZvdW5kL3BhZ2Utbm90LWZvdW5kLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.ts":
/*!************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.ts ***!
  \************************************************************/
/*! exports provided: PageNotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageNotFoundComponent", function() { return PageNotFoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let PageNotFoundComponent = class PageNotFoundComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    gotoHome() {
        this.router.navigate(['/']);
    }
};
PageNotFoundComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
PageNotFoundComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-page-not-found',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./page-not-found.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/page-not-found/page-not-found.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./page-not-found.component.css */ "./src/app/page-not-found/page-not-found.component.css")).default]
    })
], PageNotFoundComponent);



/***/ }),

/***/ "./src/app/services/blog.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/blog.service.ts ***!
  \******************************************/
/*! exports provided: BlogService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlogService", function() { return BlogService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let BlogService = class BlogService {
    constructor(http) {
        this.http = http;
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
    }
    getBlogs() {
        return this.http.get(this.serverUrl + 'api/adminBlogs').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getBlog(id) {
        return this.http.get(this.serverUrl + 'api/adminBlogs/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    createBlog(blog) {
        return this.http.post(this.serverUrl + 'api/createBlog', blog).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    updateBlog(blog, id) {
        return this.http.post(this.serverUrl + 'api/updateBlog/' + id, blog).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    deleteBlog(id) {
        return this.http.delete(this.serverUrl + 'api/deleteBlog/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Something bad happened. Please try again later.');
    }
};
BlogService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
BlogService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], BlogService);



/***/ }),

/***/ "./src/app/services/category.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/category.service.ts ***!
  \**********************************************/
/*! exports provided: CategoryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryService", function() { return CategoryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let CategoryService = class CategoryService {
    constructor(http) {
        this.http = http;
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
    }
    getcategory() {
        return this.http.get(this.serverUrl + 'api/adminCategorys').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getCategories(id) {
        // console.log('Hello');
        return this.http.get(this.serverUrl + 'api/adminCagories/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    createcategory(category) {
        return this.http.post(this.serverUrl + 'api/createcategory', category).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    updatecategory(category, id) {
        return this.http.post(this.serverUrl + 'api/updatecategory/' + id, category).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    deleteCategory(id) {
        return this.http.delete(this.serverUrl + 'api/deletecate/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Something bad happened. Please try again later.');
    }
};
CategoryService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
CategoryService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CategoryService);



/***/ }),

/***/ "./src/app/services/page.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/page.service.ts ***!
  \******************************************/
/*! exports provided: PageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageService", function() { return PageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






let PageService = class PageService {
    constructor(http) {
        this.http = http;
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].baseUrl;
    }
    getPages() {
        return this.http.get(this.serverUrl + 'api/adminPages').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    getPage(id) {
        console.log('ID API');
        return this.http.get(this.serverUrl + 'api/adminPage/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    createpage(page) {
        console.log('Create API');
        return this.http.post(this.serverUrl + 'api/createPage', page).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    updatepage(page, id) {
        console.log('updatepage API');
        return this.http.post(this.serverUrl + 'api/updatepage/' + id, page).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    deletepage(id) {
        return this.http.delete(this.serverUrl + 'api/deletePage/' + id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Something bad happened. Please try again later.');
    }
};
PageService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
PageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PageService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false,
    baseUrl: 'http://localhost/codeigniter_demo/codeIgniter1/'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! E:\ipraxa\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map